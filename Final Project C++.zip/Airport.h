// A00837313. Michelle P. González Candanosa
#ifndef Airport_h
#define Airport_h
using namespace std;
#include <string>
class Airport {
public:
    // constructors
    Airport();
    Airport(string acronym,string name);
    
    // getters
    string getAcronym(){return acronym;}
    string getName(){return name;}
    // setters
    void setAcronym(string acr){acronym=acr;}
    void setName(string n){name=n;}
    
private:
    string acronym;
    string name;
};
Airport::Airport(){
    acronym="";
    name=" ";
}
Airport::Airport(string acr, string n){
    acronym=acr;
    name=n;
}
#endif /* Airport_h */

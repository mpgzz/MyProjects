// A00837313. Michelle P. González Candanosa
#ifndef Date_h
#define Date_h
using namespace std;
#include <string>
class Date {
public:
    // constructors
    Date();
    Date(int day,int month,int year);
    
    // getters
    int getDay(){return day;}
    int getMonth(){return month;}
    int getYear(){return year;}
    // setters
    void setDay(int d){day=d;}
    void setMonth(int m){month=m;}
    void setYear(int y){year=y;}
    
private:
    int day;
    int month;
    int year;
};
Date::Date(){
    day=01;
    month=01;
    year=2000;
}
Date::Date(int d, int m, int y){
    
    day=d;
    month=m;
    year=y;
}

#endif /* Date_h */
